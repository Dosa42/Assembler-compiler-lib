const std = @import("std");
const Io = std.Io;
const DIRECTORY_ENTRY = std.coff.IMAGE.DIRECTORY_ENTRY;

const Objdump = @import("../Objdump.zig");

pub const Table = enum {
    sections,
    symbols,
    relocs,
    imports,
    exports,
    strings,
    tls,

    pub fn cliDescription(t: Table) []const u8 {
        return switch (t) {
            .sections => "Dump section headers",
            .symbols => "Dump symbol tables",
            .relocs => "Dump relocations",
            .imports => "Dump imported symbols",
            .exports => "Dump exported symbols (for implibs, dump symbol list and import headers)",
            .strings => "Dump string tables",
            .tls => "Dump TLS information",
        };
    }

    pub fn Property(comptime t: Table) type {
        return switch (t) {
            .sections => enum(u32) {
                index,
                name,
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{
                    .index = .int,
                    .name = .string,
                });
            },
            .symbols => enum(u32) {
                index,
                name,
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{
                    .index = .int,
                    .name = .string,
                });
            },
            .relocs => enum(u32) {
                index,
                symbol_name,
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{
                    .index = .int,
                    .symbol_name = .string,
                });
            },
            .imports => enum(noreturn) {
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{});
            },
            .exports => enum(u32) {
                index,
                name,
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{
                    .index = .int,
                    .name = .string,
                });
            },
            .strings => enum(noreturn) {
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{});
            },
            .tls => enum(noreturn) {
                pub const types: std.enums.EnumArray(@This(), Objdump.Table.PropertyType) = .init(.{});
            },
        };
    }
};

pub fn identifyImage(r: *Io.Reader) error{ReadFailed}!bool {
    const dos_magic = r.peek(2) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };
    if (!std.mem.eql(u8, dos_magic, "MZ")) return false;

    r.discardAll(std.coff.pe_pointer_offset) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };
    const signature_offset = r.peekInt(u32, .little) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };

    if (signature_offset < std.coff.pe_pointer_offset) return false;
    r.discardAll(signature_offset - std.coff.pe_pointer_offset) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };
    const signature = r.take(4) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };

    return std.mem.eql(u8, signature, std.coff.pe_signature);
}

pub fn identifyObject(r: *Io.Reader) error{ReadFailed}!bool {
    const machine_int = r.peekInt(u16, .little) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };
    const machine: std.coff.IMAGE.FILE.MACHINE = @fromBackingInt(machine_int);
    return switch (machine) {
        _, .UNKNOWN => false,
        else => true,
    };
}

pub fn identifyImport(r: *Io.Reader) error{ReadFailed}!bool {
    const bytes = r.peek(4) catch |err| switch (err) {
        error.EndOfStream => return false,
        else => |e| return e,
    };
    return std.mem.eql(u8, bytes, &.{ 0x00, 0x00, 0xFF, 0xFF });
}

pub fn dumpImage(d: *Objdump) Objdump.Error!void {
    // After `identifyImage` we are at the start of the COFF header.
    try d.w.print("{s}: PE/COFF image\n\n", .{d.input_name});
    dump(d, true) catch |err| switch (err) {
        else => |e| return e,

        error.EndOfStream,
        error.StreamTooLong,
        => |e| return d.fail("failed to parse COFF image: {t}", .{e}),
    };
}

pub fn dumpObject(d: *Objdump) Objdump.Error!void {
    try d.w.print("{s}: COFF object\n\n", .{d.input_name});
    dump(d, false) catch |err| switch (err) {
        else => |e| return e,

        error.EndOfStream,
        error.StreamTooLong,
        => |e| return d.fail("failed to parse COFF object: {t}", .{e}),
    };
}

pub fn dumpImport(d: *Objdump) Objdump.Error!void {
    const r = d.reader();
    const w = d.w;
    const imp_header = r.takeStruct(std.coff.ImportHeader, .little) catch |err| switch (err) {
        error.EndOfStream => return d.fail("unexpected eof reading import header", .{}),
        else => |e| return e,
    };
    const sym_name = r.takeSentinel(0) catch |err| switch (err) {
        error.EndOfStream => return d.fail("unexpected eof reading symbol name", .{}),
        error.StreamTooLong => return d.fail("symbol name in implib exceeds maximum supported length", .{}),
        else => |e| return e,
    };
    const imp_dll = r.takeSentinel(0) catch |err| switch (err) {
        error.EndOfStream => return d.fail("unexpected eof reading dll name", .{}),
        error.StreamTooLong => return d.fail("dll name in implib exceeds maximum supported length", .{}),
        else => |e| return e,
    };

    try w.print("{s}: COFF import\n\n", .{d.input_name});

    try dumpHeader(d, std.coff.ImportHeader, &imp_header, struct {
        pub fn sig1(_: *const Objdump, _: *const std.coff.ImportHeader) !void {}
        pub fn sig2(_: *const Objdump, _: *const std.coff.ImportHeader) !void {}
        pub fn types(id: *const Objdump, h: *const std.coff.ImportHeader) !void {
            try id.w.print(
                \\{t: >16} import_type
                \\{t: >16} name_type
                \\
            , .{ h.types.type, h.types.name_type });
        }
    });

    const imp_name = switch (imp_header.types.name_type) {
        .NAME_NOPREFIX => std.mem.trimStart(u8, sym_name, "?@_"),
        .NAME_UNDECORATE => std.mem.sliceTo(std.mem.trimStart(u8, sym_name, "?@_"), '@'),
        else => sym_name,
    };
    try w.print(
        \\     symbol name | {s}
        \\     import name | {s}
        \\             dll | {s}
        \\
        \\
    , .{
        sym_name,
        imp_name,
        imp_dll,
    });
}

fn dump(d: *Objdump, is_image: bool) !void {
    const gpa = d.gpa;
    const r = d.reader();
    const w = d.w;

    const file_location = d.logicalPos();
    const header = r.takeStruct(std.coff.Header, .little) catch |err|
        return d.fail("unable to read COFF header: {t}", .{err});

    if (d.opts.file_headers) {
        try w.writeAll("COFF Header:\n");
        try dumpHeader(d, std.coff.Header, &header, struct {});
        try w.writeByte('\n');
    }

    switch (header.machine) {
        _ => return d.fail("unknown machine type: {x}", .{header.machine}),
        else => {},
    }

    var known_dirs: [DIRECTORY_ENTRY.len]std.coff.ImageDataDirectory = undefined;
    const needs_data_dirs =
        d.opts.tables.coff.get(.exports) != null or
        d.opts.tables.coff.get(.imports) != null or
        d.opts.tables.coff.get(.tls) != null;

    const ImageInfo = struct {
        data_dirs: []const std.coff.ImageDataDirectory,
        magic: std.coff.OptionalHeader.Magic,
        image_base: u64,
    };

    const image_info: ?ImageInfo = if (header.size_of_optional_header > 0) image_info: {
        if (!d.opts.file_headers and !needs_data_dirs) {
            try d.seekTo(d.logicalPos() + header.size_of_optional_header);
            break :image_info null;
        }

        if (d.opts.file_headers)
            try w.writeAll("COFF Optional Header:\n");

        const magic: std.coff.OptionalHeader.Magic = @fromBackingInt(@intCast(try r.peekInt(u16, .little)));
        const num_directory_entries, const image_base = switch (magic) {
            inline .PE32, .@"PE32+" => |v| num_data_dirs: {
                const OptionalHeader = if (v == .PE32)
                    std.coff.OptionalHeader.PE32
                else
                    std.coff.OptionalHeader.@"PE32+";

                const optional_header = r.takeStruct(OptionalHeader, .little) catch |err|
                    return d.fail("unable to read optional header: {t}", .{err});

                if (d.opts.file_headers) {
                    try dumpHeader(d, OptionalHeader, &optional_header, struct {
                        pub fn base_of_code(id: *const Objdump, h: *const std.coff.OptionalHeader) !void {
                            const base = @as(*const OptionalHeader, @ptrCast(@alignCast(h))).image_base;
                            try dumpRvaField(id, @src().fn_name, h.base_of_code, base);
                        }

                        pub fn address_of_entry_point(id: *const Objdump, h: *const std.coff.OptionalHeader) !void {
                            const base = @as(*const OptionalHeader, @ptrCast(@alignCast(h))).image_base;
                            try dumpRvaField(id, @src().fn_name, h.base_of_code, base);
                        }

                        pub fn major_linker_version(id: *const Objdump, h: *const std.coff.OptionalHeader) !void {
                            try dumpVersionField(id.w, "linker_version", h.major_linker_version, h.minor_linker_version);
                        }
                        pub fn minor_linker_version(_: *const Objdump, _: *const std.coff.OptionalHeader) !void {}

                        pub fn major_operating_system_version(id: *const Objdump, h: *const OptionalHeader) !void {
                            try dumpVersionField(
                                id.w,
                                "operating_system_version",
                                h.major_operating_system_version,
                                h.minor_operating_system_version,
                            );
                        }
                        pub fn minor_operating_system_version(_: *const Objdump, _: *const OptionalHeader) !void {}

                        pub fn major_image_version(id: *const Objdump, h: *const OptionalHeader) !void {
                            try dumpVersionField(id.w, "image_version", h.major_image_version, h.minor_image_version);
                        }
                        pub fn minor_image_version(_: *const Objdump, _: *const OptionalHeader) !void {}

                        pub fn major_subsystem_version(id: *const Objdump, h: *const OptionalHeader) !void {
                            try dumpVersionField(id.w, "subsystem_version", h.major_subsystem_version, h.minor_subsystem_version);
                        }
                        pub fn minor_subsystem_version(_: *const Objdump, _: *const OptionalHeader) !void {}
                    });
                    try w.writeByte('\n');
                }

                break :num_data_dirs .{
                    optional_header.number_of_rva_and_sizes,
                    optional_header.image_base,
                };
            },
            else => return d.fail("invalid optional header magic number: {x}", .{magic}),
        };

        if (d.opts.file_headers)
            try w.writeAll("Data Directories:\n");

        for (0..num_directory_entries) |dir_i| {
            const dir = r.takeStruct(std.coff.ImageDataDirectory, .little) catch |err|
                return d.fail("unable to read data directory {x}: {t}", .{ dir_i, err });

            if (dir_i < known_dirs.len)
                known_dirs[dir_i] = dir;

            if (d.opts.file_headers)
                try w.print(
                    "{x: >16} {x: >8} {t}\n",
                    .{ dir.virtual_address, dir.size, @as(DIRECTORY_ENTRY, @fromBackingInt(@intCast(dir_i))) },
                );
        }
        if (d.opts.file_headers) try w.writeByte('\n');

        break :image_info .{
            .data_dirs = known_dirs[0..@min(known_dirs.len, num_directory_entries)],
            .magic = magic,
            .image_base = image_base,
        };
    } else if (is_image) {
        return d.fail("image did not contain an optional header", .{});
    } else null;

    // Section names in images don't use the string table, as they must fit inline in the header
    const load_string_table = (d.opts.tables.coff.get(.strings) != null or !is_image) and header.pointer_to_symbol_table > 0;
    const string_table = if (load_string_table) string_table: {
        const pos = d.logicalPos();
        d.seekTo(file_location + header.pointer_to_symbol_table + header.number_of_symbols * std.coff.Symbol.sizeOf()) catch |err|
            return d.fail("unable to seek to string table: {t}", .{err});

        const string_table_len = r.peekInt(u32, .little) catch |err|
            return d.fail("unable to read string table length: {t}", .{err});

        const table = r.readAllocAll(gpa, string_table_len) catch |err|
            return d.fail("unable to read string table: {t}", .{err});

        try d.seekTo(pos);
        break :string_table table;
    } else &.{};
    defer gpa.free(string_table);

    if (d.opts.tables.coff.get(.strings) != null) {
        if (string_table.len > 0) {
            try w.print(
                \\String Table (0x{x} bytes):
                \\
            , .{string_table.len});

            var sr = Io.Reader.fixed(string_table[@sizeOf(u32)..]);
            while (try sr.takeDelimiter(0)) |str| {
                try w.writeAll(str);
                try w.writeByte('\n');
            }

            try w.writeByte('\n');
        } else try w.writeAll("String table not present\n\n");
    }

    var sections: std.ArrayList(Section) = .empty;
    defer sections.deinit(gpa);
    var sections_with_data: u16 = 0;

    const load_sections =
        d.opts.tables.coff.get(.sections) != null or
        d.opts.tables.coff.get(.symbols) != null or
        d.opts.tables.coff.get(.relocs) != null or
        needs_data_dirs;

    if (load_sections) {
        try sections.resize(gpa, header.number_of_sections);
        for (sections.items, 0..) |*section, section_i| {
            section.header = r.takeStruct(std.coff.SectionHeader, .little) catch |err|
                return d.fail("unable to read section header {x}: {t}", .{ section_i, err });
            section.name = headerName(&section.header.name, string_table) catch |err| switch (err) {
                error.Overflow,
                error.InvalidCharacter,
                => return d.fail("unable to parse section name offset '{s}': {t}", .{
                    section.name,
                    err,
                }),
                error.OutOfBounds => return d.fail("section name offset '{s}' was out of bounds (>= {x})", .{
                    section.name,
                    string_table.len,
                }),
            };

            sections_with_data += @intFromBool(section.header.size_of_raw_data > 0);
        }

        if (d.opts.tables.coff.get(.sections)) |conf| {
            var row_it = try conf.iterateRows(d, .{ .coff = .sections }, sections.items.len, struct {
                sections: []const Section,
                pub fn property(
                    ctx: @This(),
                    index: u64,
                    comptime prop: Table.sections.Property(),
                ) Table.sections.Property().types.get(prop).ZigType() {
                    return switch (prop) {
                        .index => index,
                        .name => ctx.sections[index].name,
                    };
                }
            }, &.{ .sections = sections.items });
            defer row_it.deinit(d);
            try w.print(
                \\Sections in '{s}':
                \\Num Name          RVA Virt Size Data Size   & Data & Relocs  & Lines # Relocs  # Lines    Flags
                \\
            , .{d.input_name});
            while (row_it.next()) |section_index| {
                const section = &sections.items[section_index];
                const raw_name = std.mem.sliceTo(&section.header.name, 0);
                try w.print(
                    "{x: >3} {s: <8} {f} {f} {f} {f} {f} {f} {f} {f} {x:0>8} |",
                    .{
                        section_index + 1,
                        raw_name,
                        fmtIntField(d, section.header.virtual_address, .{ .kind = .address }),
                        fmtIntField(d, section.header.virtual_size, .{ .kind = .size, .width = .{ .explicit = 9 } }),
                        fmtIntField(d, section.header.size_of_raw_data, .{ .kind = .size, .width = .{ .explicit = 9 } }),
                        fmtIntField(d, section.header.pointer_to_raw_data, .{ .kind = .offset }),
                        fmtIntField(d, section.header.pointer_to_relocations, .{ .kind = .offset }),
                        fmtIntField(d, section.header.pointer_to_linenumbers, .{ .kind = .offset }),
                        fmtIntField(d, section.header.number_of_relocations, .{ .kind = .size }),
                        fmtIntField(d, section.header.number_of_linenumbers, .{ .kind = .size }),
                        @as(u32, @bitCast(section.header.flags)),
                    },
                );
                try dumpFlags(w, "{s}", std.coff.SectionHeader.Flags, &section.header.flags, 1);
                if (section.name.len > 8)
                    try w.print("\n  | {s}", .{section.name});

                try w.writeByte('\n');
            }
            try w.writeByte('\n');
        }
    }

    const Symbol = struct {
        is_aux: bool,
        name: []const u8,
        section_number: std.coff.SectionNumber,
        value: u32,
        type: std.coff.SymType,
        storage_class: std.coff.StorageClass,
        aux_bytes: []const u8,
    };
    var symbols: std.ArrayList(Symbol) = .empty;
    defer symbols.deinit(gpa);

    var arena: std.heap.ArenaAllocator = .init(gpa);
    defer arena.deinit();

    if (d.opts.tables.coff.get(.symbols) != null or d.opts.tables.coff.get(.relocs) != null) {
        try symbols.ensureUnusedCapacity(gpa, header.number_of_symbols);

        if (header.pointer_to_symbol_table > 0) {
            d.seekTo(file_location + header.pointer_to_symbol_table) catch |err|
                return d.fail("unable to seek to symbol table: {t}", .{err});

            const symbol_size = std.coff.Symbol.sizeOf();
            while (symbols.items.len < header.number_of_symbols) {
                const symbol_i = symbols.items.len;

                var symbol: std.coff.Symbol = undefined;
                const symbol_bytes = r.take(symbol_size) catch |err|
                    return d.fail("unable to read symbol {x}: {t}", .{ symbol_i, err });

                @memcpy(std.mem.asBytes(&symbol)[0..symbol_size], symbol_bytes);
                if (std.lang.Endian.native != .little)
                    std.mem.byteSwap(std.coff.Symbol, &symbol);

                const aux_bytes = if (symbol.number_of_aux_symbols > 0)
                    try r.readAllocAll(arena.allocator(), symbol_size * symbol.number_of_aux_symbols)
                else
                    &.{};

                const name = if (std.mem.eql(u8, symbol.name[0..4], "\x00\x00\x00\x00")) name: {
                    const index = std.mem.readInt(u32, symbol.name[4..], .little);
                    if (index >= string_table.len)
                        return d.fail("invalid name offset for symbol {x} ({x} >= {x})", .{
                            symbol_i,
                            index,
                            string_table.len,
                        });
                    break :name std.mem.sliceTo(string_table[index..], 0);
                } else try arena.allocator().dupe(u8, std.mem.sliceTo(&symbol.name, 0));

                symbols.appendAssumeCapacity(.{
                    .is_aux = false,
                    .name = name,
                    .section_number = symbol.section_number,
                    .value = symbol.value,
                    .type = symbol.type,
                    .storage_class = symbol.storage_class,
                    .aux_bytes = aux_bytes,
                });
                symbols.appendNTimesAssumeCapacity(.{
                    .is_aux = true,
                    .name = name,
                    .section_number = symbol.section_number,
                    .value = symbol.value,
                    .type = symbol.type,
                    .storage_class = symbol.storage_class,
                    .aux_bytes = aux_bytes,
                }, symbol.number_of_aux_symbols);
            }

            if (d.opts.tables.coff.get(.symbols)) |conf| {
                var row_it = try conf.iterateRows(d, .{ .coff = .symbols }, symbols.items.len, struct {
                    symbols: []const Symbol,
                    pub fn property(
                        ctx: @This(),
                        index: u64,
                        comptime prop: Table.symbols.Property(),
                    ) Table.symbols.Property().types.get(prop).ZigType() {
                        return switch (prop) {
                            .index => index,
                            .name => ctx.symbols[index].name,
                        };
                    }
                }, &.{ .symbols = symbols.items });
                defer row_it.deinit(d);

                try w.print(
                    \\Symbols in '{s}':
                    \\ Ord    Value  Sect Type           Storage   Name
                    \\
                , .{d.input_name});

                while (row_it.next()) |symbol_i| {
                    const symbol = &symbols.items[symbol_i];

                    if (symbol.is_aux) continue;

                    try w.print("{f} {x:0>8} ", .{
                        fmtIntField(d, @as(u16, @intCast(symbol_i)), .{ .kind = .index }),
                        symbol.value,
                    });
                    try switch (symbol.section_number) {
                        .UNDEFINED => w.writeAll("UNDEF"),
                        .ABSOLUTE => w.writeAll("  ABS"),
                        .DEBUG => w.writeAll("DEBUG"),
                        else => |v| {
                            const backing = @backingInt(v);
                            const fmt = "{x: >5}";
                            if (backing >= 0)
                                try w.print(fmt, .{@as(u15, @intCast(backing))})
                            else
                                try w.print(fmt, .{backing});
                        },
                    };

                    try w.print("{t: >5}", .{symbol.type.base_type});
                    if (switch (symbol.type.complex_type) {
                        .NULL => "  ",
                        .POINTER => "* ",
                        .FUNCTION => "()",
                        .ARRAY => "[]",
                        else => null,
                    }) |suffix| try w.writeAll(suffix) else try w.print("{x}", .{symbol.type.complex_type});

                    try w.print("{t: >16} | {s}\n", .{ symbol.storage_class, symbol.name });

                    if (symbol.aux_bytes.len == 0) continue;
                    try w.writeAll("   |");

                    if (symbol.storage_class == .EXTERNAL and
                        symbol.type == std.coff.SymType{
                            .complex_type = .FUNCTION,
                            .base_type = .NULL,
                        } and
                        @backingInt(symbol.section_number) > 0)
                    {
                        try w.writeAll("TODO function aux symbol");
                    } else if (symbol.type == std.coff.SymType{
                        .complex_type = .FUNCTION,
                        .base_type = .NULL,
                    } and
                        (std.mem.eql(u8, symbol.name, ".bf") or std.mem.eql(u8, symbol.name, ".ef")))
                    {
                        try w.writeAll("TODO bf / ef aux symbol");
                    } else if (symbol.storage_class == .WEAK_EXTERNAL and symbol.section_number == .UNDEFINED) {
                        if (symbol.value != 0)
                            return d.fail(
                                "invalid value 0x{x} for weak external symbol 0x{x}",
                                .{ symbol.value, symbol_i },
                            );

                        var weak_external: std.coff.WeakExternalDefinition = undefined;
                        @memcpy(std.mem.asBytes(&weak_external)[0..symbol_size], symbol.aux_bytes[0..symbol_size]);
                        if (std.lang.Endian.native != .little)
                            std.mem.byteSwap(std.coff.WeakExternalDefinition, &weak_external);

                        if (weak_external.tag_index >= header.number_of_symbols)
                            return d.fail(
                                "invalid tag_index 0x{x} for weak external symbol 0x{x}",
                                .{ weak_external.tag_index, symbol_i },
                            );

                        if (d.opts.redact.contains(.index))
                            try w.print("  Weak External [falls back to relative ordinal {x:0>8} via {t}]", .{
                                @as(i64, weak_external.tag_index) - @as(i64, @intCast(symbol_i)),
                                weak_external.flag,
                            })
                        else
                            try w.print("  Weak External [falls back to ordinal {x:0>8} via {t}]", .{
                                weak_external.tag_index,
                                weak_external.flag,
                            });
                    } else if (symbol.storage_class == .FILE) {
                        if (!std.mem.eql(u8, symbol.name, ".file")) {
                            try w.print(" !! unexpected symbol name '{s}' for file symbol 0x{x}", .{ symbol.name, symbol_i });
                            continue;
                        }

                        const filename = std.mem.sliceTo(symbol.aux_bytes, 0);
                        try w.print("     File       '{s}'", .{filename});
                        break;
                    } else if (symbol.storage_class == .STATIC and
                        symbol.type == std.coff.SymType{
                            .complex_type = .NULL,
                            .base_type = .NULL,
                        } and
                        symbol.value == 0 and
                        switch (symbol.section_number) {
                            .UNDEFINED, .DEBUG, .ABSOLUTE => false,
                            else => |sn| @backingInt(sn) > 0,
                        })
                    {
                        const section_i: u15 = @intCast(@backingInt(symbol.section_number) - 1);
                        try w.writeAll("  Section ");

                        if (section_i >= sections.items.len) {
                            try w.print(" !! invalid section number: {x}", .{section_i});
                            continue;
                        }

                        var section_def: std.coff.SectionDefinition = undefined;
                        @memcpy(std.mem.asBytes(&section_def)[0..symbol_size], symbol.aux_bytes[0..symbol_size]);
                        if (std.lang.Endian.native != .little)
                            std.mem.byteSwap(std.coff.SectionDefinition, &section_def);

                        const section = &sections.items[section_i];
                        if (section_def.number_of_relocations != section.header.number_of_relocations) {
                            try w.print(
                                " !! relocation count did not match section header: {d} vs {d}",
                                .{ section_def.number_of_relocations, section.header.number_of_relocations },
                            );
                            continue;
                        }

                        if (section_def.number_of_linenumbers != section.header.number_of_linenumbers) {
                            try w.print(
                                " !! line number count did not match section header: {d} vs {d}",
                                .{ section_def.number_of_linenumbers, section.header.number_of_linenumbers },
                            );
                            continue;
                        }

                        try w.print("      [size {f} chksum {x:0>8} relocs {x:0>4} lines {x:0>4}]", .{
                            fmtIntField(d, section_def.length, .{ .kind = .size, .zero_fill = true }),
                            section_def.checksum,
                            section_def.number_of_relocations,
                            section_def.number_of_linenumbers,
                        });

                        switch (section_def.selection) {
                            .NONE => {},
                            else => |selection| {
                                try w.print(" COMDAT({t}", .{selection});
                                if (selection == .ASSOCIATIVE)
                                    try w.print("->{x}", .{section_def.number});
                                try w.writeAll(")");
                            },
                        }
                    }

                    try w.writeByte('\n');
                }

                try w.writeByte('\n');
            }
        } else if (d.opts.tables.coff.get(.symbols) != null) {
            try w.writeAll("No symbol table found\n\n");
        }
    }

    if (d.opts.tables.coff.get(.relocs)) |relocs_conf| {
        const relocation_size = std.coff.Relocation.sizeOf();

        for (sections.items, 0..) |section, section_i| {
            if (section.header.pointer_to_relocations == 0) continue;

            const relocs = try gpa.alloc(std.coff.Relocation, section.header.number_of_relocations);
            defer gpa.free(relocs);

            d.seekTo(file_location + section.header.pointer_to_relocations) catch |err|
                return d.fail("unable to seek to section {x} relocation table: {t}", .{ section_i + 1, err });

            for (relocs) |*reloc| {
                @memcpy(std.mem.asBytes(reloc)[0..relocation_size], try r.take(relocation_size));
                if (std.lang.Endian.native != .little)
                    std.mem.byteSwap(std.coff.Relocation, reloc);
            }

            var row_it = try relocs_conf.iterateRows(d, .{ .coff = .relocs }, relocs.len, struct {
                symbols: []const Symbol,
                relocs: []const std.coff.Relocation,
                pub fn property(
                    ctx: @This(),
                    index: u64,
                    comptime prop: Table.relocs.Property(),
                ) Table.relocs.Property().types.get(prop).ZigType() {
                    return switch (prop) {
                        .index => index,
                        .symbol_name => {
                            const sym_index = ctx.relocs[index].symbol_table_index;
                            if (sym_index >= ctx.symbols.len) return "";
                            return ctx.symbols[sym_index].name;
                        },
                    };
                }
            }, &.{ .symbols = symbols.items, .relocs = relocs });
            defer row_it.deinit(d);

            try w.print(
                \\Relocs for section {x} '{s}' in {s}:
                \\  Offset Type                Symbol -> Sect   Name
                \\
            , .{ section_i + 1, section.name, d.input_name });

            while (row_it.next()) |reloc_i| {
                const reloc = &relocs[reloc_i];
                const sym = &symbols.items[reloc.symbol_table_index];

                try w.print("{f} ", .{
                    fmtIntField(d, reloc.virtual_address, .{ .kind = .address, .zero_fill = true }),
                });
                switch (header.machine) {
                    _ => unreachable,
                    inline else => |m| switch (m.RelocationType()) {
                        void => try w.writeAll("(unknown arch)"),
                        else => |RelocationType| try w.print(
                            "{t: <17} ",
                            .{@as(RelocationType, @fromBackingInt(@intCast(reloc.type)))},
                        ),
                    },
                }

                if (reloc.symbol_table_index >= symbols.items.len)
                    return d.fail(
                        "reloc {x} in section {x} has out-of-bounds symbol index {x}",
                        .{ reloc_i, section_i + 1, reloc.symbol_table_index },
                    );

                try w.print("{f}   {f} | {s}\n", .{
                    fmtIntField(d, reloc.symbol_table_index, .{ .kind = .index }),
                    fmtSectionNumber(sym.section_number),
                    sym.name,
                });
            }
            try w.writeByte('\n');
        }
    }

    // Sections indices with raw data, sorted by RVA
    const rva_index = if (needs_data_dirs) rva_index: {
        const rva_index = try gpa.alloc(u16, sections_with_data);
        var indices_i: u16 = 0;
        for (sections.items, 0..) |*section, i| {
            if (section.header.size_of_raw_data == 0) continue;
            rva_index[indices_i] = @intCast(i);
            indices_i += 1;
        }

        const Context = struct {
            indices: []u16,
            sections: []const Section,

            pub fn lessThan(ctx: @This(), lhs: usize, rhs: usize) bool {
                return ctx.sections[ctx.indices[lhs]].header.virtual_address <
                    ctx.sections[ctx.indices[rhs]].header.virtual_address;
            }

            pub fn swap(ctx: @This(), lhs: usize, rhs: usize) void {
                std.mem.swap(u16, &ctx.indices[lhs], &ctx.indices[rhs]);
            }
        };

        std.sort.pdqContext(0, rva_index.len, Context{
            .indices = rva_index,
            .sections = sections.items,
        });

        break :rva_index rva_index;
    } else &.{};
    defer gpa.free(rva_index);

    if (d.opts.tables.coff.get(.exports)) |exports_conf| exports: {
        if (try seekToDataDirectory(
            d,
            rva_index,
            sections.items,
            (image_info orelse break :exports).data_dirs,
            .EXPORT,
        )) |section_index| {
            const export_dir = r.takeStruct(std.coff.ExportDirectoryTable, .little) catch |err|
                return d.fail("unable to read export directory: {t}", .{err});

            try w.print("Export directory:\n", .{});
            try dumpHeader(d, std.coff.ExportDirectoryTable, &export_dir, struct {
                pub fn major_version(id: *const Objdump, h: *const std.coff.ExportDirectoryTable) !void {
                    try dumpVersionField(id.w, "version", h.major_version, h.minor_version);
                }
                pub fn minor_version(_: *const Objdump, _: *const std.coff.ExportDirectoryTable) !void {}
            });

            const section = sections.items[section_index];
            const name_loc = section.rvaFileOffset(export_dir.name_rva) catch
                return d.fail(
                    "export name rva 0x{x} was not within the export section",
                    .{export_dir.name_rva},
                );

            const eat_loc = section.rvaFileOffset(export_dir.export_address_table_rva) catch
                return d.fail(
                    "export address table rva 0x{x} was not within the export section",
                    .{export_dir.export_address_table_rva},
                );

            const name_pointer_loc = section.rvaFileOffset(export_dir.name_pointer_table_rva) catch
                return d.fail(
                    "export name pointer table rva 0x{x} was not within the export section",
                    .{export_dir.name_pointer_table_rva},
                );

            const ord_loc = section.rvaFileOffset(export_dir.ordinal_table_rva) catch
                return d.fail(
                    "export ordinal table rva 0x{x} was not within the export section",
                    .{export_dir.ordinal_table_rva},
                );

            // All the variable length fields should be contained within this directory.
            // Read it entirely to avoid needing to seek per-name when iterating.
            const dir = image_info.?.data_dirs[@backingInt(DIRECTORY_ENTRY.EXPORT)];
            const dir_end_rva = dir.virtual_address + dir.size;
            const dir_loc = d.logicalPos();
            const dir_slice = try r.readAllocAll(gpa, dir.size);
            defer gpa.free(dir_slice);

            const dll_name = std.mem.sliceTo(dir_slice[@intCast(name_loc - dir_loc)..], 0);

            const name_pointers = dir_slice[@intCast(name_pointer_loc - dir_loc)..][0 .. export_dir.number_of_names * @sizeOf(u32)];
            const ords = dir_slice[@intCast(ord_loc - dir_loc)..][0 .. export_dir.number_of_names * @sizeOf(u16)];
            const addrs = dir_slice[@intCast(eat_loc - dir_loc)..][0 .. export_dir.number_of_entries * @sizeOf(u32)];
            const name_rva_to_offset = dir.virtual_address + @sizeOf(std.coff.ExportDirectoryTable);

            var row_it = try exports_conf.iterateRows(d, .{ .coff = .exports }, export_dir.number_of_names, struct {
                dir_slice: []const u8,
                name_pointers: []const u8,
                name_rva_to_offset: u32,
                pub fn property(
                    ctx: @This(),
                    index: u64,
                    comptime prop: Table.exports.Property(),
                ) Table.exports.Property().types.get(prop).ZigType() {
                    return switch (prop) {
                        .index => index,
                        .name => {
                            const name_rva = std.mem.readInt(u32, ctx.name_pointers[index * @sizeOf(u32) ..][0..@sizeOf(u32)], .little);
                            return std.mem.sliceTo(ctx.dir_slice[name_rva - ctx.name_rva_to_offset ..], 0);
                        },
                    };
                }
            }, &.{
                .dir_slice = dir_slice,
                .name_pointers = name_pointers,
                .name_rva_to_offset = name_rva_to_offset,
            });
            defer row_it.deinit(d);

            try w.print(
                \\
                \\Exports from {s}:
                \\ Ord Hint      RVA   Name
                \\
            , .{dll_name});

            while (row_it.next()) |name_i| {
                const name_rva = std.mem.readInt(u32, name_pointers[name_i * @sizeOf(u32) ..][0..@sizeOf(u32)], .little);
                const name = std.mem.sliceTo(dir_slice[name_rva - name_rva_to_offset ..], 0);
                const ord = std.mem.readInt(u16, ords[name_i * @sizeOf(u16) ..][0..@sizeOf(u16)], .little);
                const addr = std.mem.readInt(u32, addrs[@as(u32, ord) * @sizeOf(u32) ..][0..@sizeOf(u32)], .little);

                try w.print("{f} {f} ", .{
                    fmtIntField(d, @as(u16, @intCast(export_dir.ordinal_base + ord)), .{ .kind = .index }),
                    fmtIntField(d, @as(u16, @intCast(name_i)), .{ .kind = .index }),
                });
                const is_forwarder = addr >= dir.virtual_address and addr < dir_end_rva;
                if (is_forwarder) {
                    try w.writeAll("forwards");
                } else {
                    try w.print("{f}", .{fmtIntField(d, addr, .{ .kind = .address })});
                }

                try w.print(" | {s}", .{name});
                if (is_forwarder)
                    try w.print(" -> {s}", .{std.mem.sliceTo(dir_slice[addr - name_rva_to_offset ..], 0)});
                try w.writeByte('\n');
            }
            try w.writeByte('\n');
        }
    }

    if (d.opts.tables.coff.get(.imports) != null) imports: {
        if (try seekToDataDirectory(
            d,
            rva_index,
            sections.items,
            (image_info orelse break :imports).data_dirs,
            .IMPORT,
        )) |_| {
            const Entry = std.coff.ImportDirectoryEntry;
            var directory_entries: std.ArrayList(Entry) = .empty;
            defer directory_entries.deinit(gpa);
            while (true) {
                const entry = r.takeStruct(Entry, .little) catch |err|
                    return d.fail(
                        "unable to read import directory entry {x}: {t}",
                        .{ directory_entries.items.len, err },
                    );

                if (std.mem.allEqual(u8, std.mem.asBytes(&entry), 0)) break;
                (try directory_entries.addOne(gpa)).* = entry;
            }

            for (directory_entries.items) |entry| {
                const name_section = sectionContainingRva(
                    rva_index,
                    sections.items,
                    entry.name_rva,
                ) orelse
                    return d.fail(
                        "import directory entry name rva 0x{x} was not found in any section",
                        .{entry.name_rva},
                    );

                const name_loc = sections.items[name_section].rvaFileOffset(
                    entry.name_rva,
                ) catch unreachable;
                d.seekTo(name_loc) catch |err|
                    return d.fail(
                        "unable to seek to import directory entry name at 0x{x}: {t}",
                        .{ name_loc, err },
                    );

                const dll_name = (try r.takeDelimiter(0)).?;

                try w.print("Import table entry for {s}:\n", .{dll_name});
                try dumpHeader(d, Entry, &entry, struct {});

                try w.print(
                    \\
                    \\ Ord Hint   Name
                    \\
                , .{});

                const ilt_section = sectionContainingRva(
                    rva_index,
                    sections.items,
                    entry.import_lookup_table_rva,
                ) orelse
                    return d.fail(
                        "import directory entry ilt rva 0x{x} was not found in any section",
                        .{entry.import_lookup_table_rva},
                    );

                const ilt_loc = sections.items[ilt_section].rvaFileOffset(
                    entry.import_lookup_table_rva,
                ) catch unreachable;
                d.seekTo(ilt_loc) catch |err|
                    return d.fail(
                        "unable to seek to import directory ilt at 0x{x}: {t}",
                        .{ ilt_loc, err },
                    );

                switch (image_info.?.magic) {
                    _ => try w.writeAll("(unknown magic)\n\n"),
                    inline else => |m| {
                        const TableEntry = std.coff.ImportLookupTableEntry(m);
                        const null_entry: TableEntry = @bitCast(@as(@typeInfo(TableEntry).@"struct".backing_integer.?, 0));

                        var ilt_entries: std.ArrayList(TableEntry) = .empty;
                        defer ilt_entries.deinit(gpa);
                        while (true) {
                            const table_entry = r.takeStruct(TableEntry, .little) catch |err|
                                return d.fail(
                                    "unable to read ilt entry {s}:{x}: {t}",
                                    .{ dll_name, ilt_entries.items.len, err },
                                );
                            if (table_entry == null_entry) break;
                            (try ilt_entries.addOne(gpa)).* = table_entry;
                        }

                        for (ilt_entries.items, 0..) |ilt_entry, ilt_entry_i| {
                            if (ilt_entry.is_ordinal) {
                                try w.print("{x: >4}", .{ilt_entry.payload.ordinal.ordinal});
                            } else {
                                const hint_section = sectionContainingRva(
                                    rva_index,
                                    sections.items,
                                    ilt_entry.payload.hint_name_rva,
                                ) orelse
                                    return d.fail(
                                        "import directory ilt entry 0x{x}'s hint rva 0x{x} was not found in any section",
                                        .{ ilt_entry_i, ilt_entry.payload.hint_name_rva },
                                    );

                                const hint_loc = sections.items[hint_section].rvaFileOffset(
                                    ilt_entry.payload.hint_name_rva,
                                ) catch unreachable;
                                d.seekTo(hint_loc) catch |err|
                                    return d.fail(
                                        "unable to seek to ilt entry 0x{x}'s hint at 0x{x}: {t}",
                                        .{ ilt_entry_i, hint_loc, err },
                                    );

                                const hint = r.takeInt(u16, .little) catch |err|
                                    return d.fail(
                                        "unable to read import directory ilt entry 0x{x}'s hint: {t}",
                                        .{ ilt_entry_i, err },
                                    );

                                const name = r.takeDelimiter(0) catch |err|
                                    return d.fail(
                                        "unable to read import directory ilt entry 0x{x}'s name: {t}",
                                        .{ ilt_entry_i, err },
                                    );

                                try w.print("     {x: >4} | {s}\n", .{ hint, name.? });
                            }
                        }
                        try w.writeByte('\n');
                    },
                }
            }
        }
    }

    if (d.opts.tables.coff.get(.tls) != null) tls: {
        if (try seekToDataDirectory(
            d,
            rva_index,
            sections.items,
            (image_info orelse break :tls).data_dirs,
            .TLS,
        )) |_| {
            switch (image_info.?.magic) {
                _ => try w.writeAll("(unknown magic)\n\n"),
                inline else => |m| {
                    const TlsDirectoryEntry = std.coff.TlsDirectoryEntry(m);
                    const tls_entry = r.takeStruct(TlsDirectoryEntry, .little) catch |err|
                        return d.fail("unable to read tls directory: {t}", .{err});

                    try w.writeAll("TLS Directory:\n");
                    try dumpHeader(d, TlsDirectoryEntry, &tls_entry, struct {});

                    try w.writeAll("               | ");
                    if (tls_entry.characteristics.alignment == .NONE) {
                        try w.writeAll("Alignment not specified");
                    } else {
                        try w.print(
                            "Alignment: {d}",
                            .{tls_entry.characteristics.alignment.toByteUnits().?},
                        );
                    }

                    try w.writeAll(
                        \\
                        \\
                        \\TLS Callbacks:
                        \\         Address
                        \\
                    );

                    const callbacks_rva: u32 = @intCast(tls_entry.callbacks_va - image_info.?.image_base);
                    const section_index = sectionContainingRva(
                        rva_index,
                        sections.items,
                        callbacks_rva,
                    ) orelse
                        return d.fail(
                            "tls callbacks rva 0x{x} was not found in any section",
                            .{callbacks_rva},
                        );

                    const callbacks_loc = sections.items[section_index]
                        .rvaFileOffset(callbacks_rva) catch unreachable;

                    d.seekTo(callbacks_loc) catch |err|
                        return d.fail(
                            "unable to seek to tls callbacks array at offset 0x{x}: {t}",
                            .{ callbacks_loc, err },
                        );

                    while (true) {
                        const callback_va = r.takeInt(@FieldType(TlsDirectoryEntry, "callbacks_va"), .little) catch |err|
                            return d.fail(
                                "unable to read tls callbacks array: {t}",
                                .{err},
                            );

                        try w.print("{f}\n", .{fmtIntField(d, callback_va, .{ .kind = .address })});
                        if (callback_va == 0) break;
                    }
                    try w.writeByte('\n');
                },
            }
        }
    }
}

const Section = struct {
    header: std.coff.SectionHeader,
    name: []const u8,

    fn rvaFileOffset(section: *const Section, rva: u32) !u32 {
        if (rva < section.header.virtual_address or
            rva >= section.header.virtual_address + section.header.size_of_raw_data)
            return error.OutOfBounds;

        return section.header.pointer_to_raw_data + (rva - section.header.virtual_address);
    }
};

fn seekToDataDirectory(
    d: *Objdump,
    rva_index: []const u16,
    sections: []const Section,
    data_dirs: []const std.coff.ImageDataDirectory,
    entry: DIRECTORY_ENTRY,
) !?u16 {
    if (@backingInt(entry) < data_dirs.len) blk: {
        const rva = data_dirs[@backingInt(entry)].virtual_address;
        if (rva == 0) break :blk;

        const section_index = sectionContainingRva(rva_index, sections, rva) orelse
            return d.fail(
                "{t} directory rva 0x{x} was not found in any section",
                .{ entry, rva },
            );

        const file_offset = sections[section_index].rvaFileOffset(rva) catch unreachable;
        d.seekTo(file_offset) catch |err|
            return d.fail(
                "unable to seek to {t} directory at offset 0x{x}: {t}",
                .{ entry, file_offset, err },
            );

        return section_index;
    }

    try d.w.print("{t} directory was not present in optional header\n\n", .{entry});
    return null;
}

fn sectionContainingRva(
    /// Indices into `sections` sorted by rva
    indices: []const u16,
    sections: []const Section,
    rva: u32,
) ?u16 {
    const Context = struct {
        rva: u32,
        sections: []const Section,

        fn order(ctx: @This(), section_index: u16) std.math.Order {
            const h = &ctx.sections[section_index].header;
            if (ctx.rva < h.virtual_address) return .lt;
            const end = h.virtual_address + h.size_of_raw_data;
            if (ctx.rva >= end) return .gt;
            return .eq;
        }
    };

    const indices_index = std.sort.binarySearch(u16, indices, Context{
        .rva = rva,
        .sections = sections,
    }, Context.order) orelse return null;
    return @intCast(indices[indices_index]);
}

fn headerName(raw: *const [8]u8, string_table: []const u8) ![]const u8 {
    return if (raw[0] == '/') name: {
        const name_offset = try std.fmt.parseUnsigned(u24, std.mem.sliceTo(raw[1..], 0), 10);
        if (name_offset >= string_table.len)
            return error.OutOfBounds;

        break :name std.mem.sliceTo(string_table[name_offset..], 0);
    } else std.mem.sliceTo(raw, 0);
}

fn fmtSectionNumber(section_number: std.coff.SectionNumber) std.fmt.Alt(std.coff.SectionNumber, sectionNumberString) {
    return .{ .data = section_number };
}

fn sectionNumberString(section_number: std.coff.SectionNumber, w: *std.Io.Writer) std.Io.Writer.Error!void {
    try switch (section_number) {
        .UNDEFINED => w.writeAll("UNDEF"),
        .ABSOLUTE => w.writeAll("  ABS"),
        .DEBUG => w.writeAll("DEBUG"),
        else => |v| {
            const backing = @backingInt(v);
            const fmt = "{x: >5}";
            if (backing >= 0)
                try w.print(fmt, .{@as(u15, @intCast(backing))})
            else
                try w.print(fmt, .{backing});
        },
    };
}

const FormatIntField = struct {
    val: ?u64,
    width: ?usize,
    zero_fill: bool,
};

fn fmtIntField(
    d: *const Objdump,
    val: anytype,
    params: struct {
        kind: ?Objdump.FieldKind = null,
        width: union(enum) {
            fit_max,
            auto,
            explicit: usize,
        } = .fit_max,
        zero_fill: bool = false,
    },
) std.fmt.Alt(FormatIntField, intFieldString) {
    return .{
        .data = .{
            .val = val: {
                if (params.kind) |k| {
                    if (d.opts.redact.contains(k)) {
                        break :val null;
                    }
                }
                break :val val;
            },
            .width = switch (params.width) {
                .fit_max => @typeInfo(@TypeOf(val)).int.bits / 4,
                .auto => null,
                .explicit => |w| w,
            },
            .zero_fill = params.zero_fill,
        },
    };
}

fn intFieldString(field: FormatIntField, w: *std.Io.Writer) std.Io.Writer.Error!void {
    if (field.val) |val| {
        try w.printInt(val, 16, .lower, .{
            .width = field.width,
            .alignment = .right,
            .fill = if (field.zero_fill) '0' else ' ',
        });
    } else try w.splatByteAll('x', field.width orelse 1);
}

fn dumpFlags(w: *Io.Writer, comptime fmt: []const u8, comptime T: type, flags: *const T, cols: u32) !void {
    const s = @typeInfo(T).@"struct";
    inline for (s.field_names, s.field_types) |field_name, field_type| {
        if (field_type == bool and @field(flags, field_name)) {
            try w.splatByteAll(' ', cols);
            try w.print(fmt, .{field_name});
        }
    }
}

fn fieldKind(name: []const u8) ?Objdump.FieldKind {
    if (std.mem.endsWith(u8, name, "_rva") or
        std.mem.endsWith(u8, name, "_va") or
        std.mem.endsWith(u8, name, "_address"))
    {
        return .address;
    }

    if (std.mem.startsWith(u8, name, "pointer_")) {
        return .offset;
    }

    if (std.mem.startsWith(u8, name, "number_") or
        std.mem.startsWith(u8, name, "size"))
    {
        return .size;
    }

    if (std.mem.startsWith(u8, name, "hint")) {
        return .index;
    }

    return null;
}

fn dumpHeader(
    d: *const Objdump,
    comptime T: type,
    header: *const T,
    Custom: type,
) !void {
    const s = @typeInfo(T).@"struct";
    inline for (s.field_names, s.field_types) |field_name, field_type| {
        const val = &@field(header, field_name);
        if (@hasDecl(Custom, field_name)) {
            try @field(Custom, field_name)(d, header);
        } else {
            switch (@typeInfo(field_type)) {
                .int => try d.w.print("{f} {s}\n", .{ fmtIntField(d, val.*, .{
                    .kind = comptime fieldKind(field_name),
                    .width = .{ .explicit = 16 },
                }), field_name }),
                .@"enum" => try d.w.print("{x: >16} {s} ({t})\n", .{ val.*, field_name, val.* }),
                .@"struct" => |s_field| {
                    switch (s_field.layout) {
                        .auto,
                        .@"extern",
                        => try dumpHeader(d, field_type, val, Custom),
                        .@"bitpack" => {
                            try d.w.print("{x: >16} {s}\n", .{ @as(s_field.backing_integer.?, @bitCast(val.*)), field_name });
                            try dumpFlags(d.w, "| {s}\n", field_type, val, 15);
                        },
                    }
                },
                else => unreachable,
            }
        }
    }
}

fn dumpVersionField(w: *Io.Writer, name: []const u8, major: anytype, minor: anytype) !void {
    try w.print("{d: >13}.{x:0<2} {s}\n", .{ major, minor, name });
}

fn dumpRvaField(d: *const Objdump, name: []const u8, rva: u64, base: u64) !void {
    try d.w.print("{f} {s} ({f})\n", .{
        fmtIntField(d, rva, .{ .kind = .address }),
        name,
        fmtIntField(d, base + rva, .{ .kind = .address }),
    });
}
