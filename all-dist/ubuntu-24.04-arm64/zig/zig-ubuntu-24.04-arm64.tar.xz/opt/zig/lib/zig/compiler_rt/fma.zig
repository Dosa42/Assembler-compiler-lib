//! Ported from musl, which is MIT licensed:
//! https://git.musl-libc.org/cgit/musl/tree/COPYRIGHT
//!
//! https://git.musl-libc.org/cgit/musl/tree/src/math/fmal.c
//! https://git.musl-libc.org/cgit/musl/tree/src/math/fmaf.c
//! https://git.musl-libc.org/cgit/musl/tree/src/math/fma.c

const std = @import("std");
const math = std.math;
const expect = std.testing.expect;
const expectEqual = std.testing.expectEqual;
const compiler_rt = @import("../compiler_rt.zig");
const symbol = compiler_rt.symbol;

comptime {
    symbol(&__fmah, "__fmah");
    symbol(&fmaf, "fmaf");
    symbol(&fma, "fma");
    symbol(&__fmax, "__fmax");
    symbol(&fmaq, "fmaf128");
    if (compiler_rt.have_c_longdouble) symbol(&fmal, "fmal");
}

fn __fmah(x: compiler_rt.f16.Abi, y: compiler_rt.f16.Abi, z: compiler_rt.f16.Abi) callconv(.c) compiler_rt.f16.Abi {
    return compiler_rt.f16.toAbi(fma_f16(compiler_rt.f16.fromAbi(x), compiler_rt.f16.fromAbi(y), compiler_rt.f16.fromAbi(z)));
}
pub fn fma_f16(x: f16, y: f16, z: f16) f16 {
    // TODO: more efficient implementation
    return @floatCast(fma_f32(x, y, z));
}

fn fmaf(x: compiler_rt.f32.Abi, y: compiler_rt.f32.Abi, z: compiler_rt.f32.Abi) callconv(.c) compiler_rt.f32.Abi {
    return compiler_rt.f32.toAbi(fma_f32(compiler_rt.f32.fromAbi(x), compiler_rt.f32.fromAbi(y), compiler_rt.f32.fromAbi(z)));
}
pub fn fma_f32(x: f32, y: f32, z: f32) f32 {
    const xy = @as(f64, x) * y;
    const xy_z = xy + z;
    const u = @as(u64, @bitCast(xy_z));
    const e = (u >> 52) & 0x7FF;

    if ((u & 0x1FFFFFFF) != 0x10000000 or e == 0x7FF or (xy_z - xy == z and xy_z - z == xy)) {
        return @floatCast(xy_z);
    } else {
        // Correct double rounding at an f32 midpoint.
        const negative = u >> 63 != 0;
        const err = if (negative == (z > xy)) xy - xy_z + z else z - xy_z + xy;
        return @floatCast(@as(f64, @bitCast(if (negative == (err < 0)) u + 1 else u - 1)));
    }
}

fn fma(x: compiler_rt.f64.Abi, y: compiler_rt.f64.Abi, z: compiler_rt.f64.Abi) callconv(.c) compiler_rt.f64.Abi {
    return compiler_rt.f64.toAbi(fma_f64(compiler_rt.f64.fromAbi(x), compiler_rt.f64.fromAbi(y), compiler_rt.f64.fromAbi(z)));
}
/// NOTE: Upstream fma.c has been rewritten completely to raise fp exceptions more accurately.
pub fn fma_f64(x: f64, y: f64, z: f64) f64 {
    if (!math.isFinite(x) or !math.isFinite(y)) {
        return x * y + z;
    }
    if (!math.isFinite(z)) {
        return z;
    }
    if (x == 0.0 or y == 0.0) {
        return x * y + z;
    }
    if (z == 0.0) {
        return x * y;
    }

    const x1 = math.frexp(x);
    const ex = x1.exponent;
    const xs = x1.significand;
    const x2 = math.frexp(y);
    const ey = x2.exponent;
    const ys = x2.significand;
    const x3 = math.frexp(z);
    const ez = x3.exponent;
    var zs = x3.significand;

    var spread = ex + ey - ez;
    if (spread < -53) return z;
    if (spread <= 53 * 2) {
        zs = math.scalbn(zs, -spread);
    } else {
        zs = math.copysign(math.floatMin(f64), zs);
    }

    const xy = dd_mul(xs, ys);
    const r = dd_add(xy.hi, zs);
    spread = ex + ey;

    if (r.hi == 0.0) {
        return if (xy.lo == 0.0) xy.hi + zs else math.scalbn(xy.lo, spread);
    }

    const adj = add_adjusted(r.lo, xy.lo);
    if (spread + math.ilogb(r.hi) > -1023) {
        return math.scalbn(r.hi + adj, spread);
    } else {
        return add_and_denorm(r.hi, adj, spread);
    }
}

fn __fmax(a: compiler_rt.f80.Abi, b: compiler_rt.f80.Abi, c: compiler_rt.f80.Abi) callconv(.c) compiler_rt.f80.Abi {
    return compiler_rt.f80.toAbi(fma_f80(compiler_rt.f80.fromAbi(a), compiler_rt.f80.fromAbi(b), compiler_rt.f80.fromAbi(c)));
}
pub fn fma_f80(a: f80, b: f80, c: f80) f80 {
    // TODO: more efficient implementation
    return @floatCast(fma_f128(a, b, c));
}

fn fmaq(x: compiler_rt.f128.Abi, y: compiler_rt.f128.Abi, z: compiler_rt.f128.Abi) callconv(.c) compiler_rt.f128.Abi {
    return compiler_rt.f128.toAbi(fma_f128(compiler_rt.f128.fromAbi(x), compiler_rt.f128.fromAbi(y), compiler_rt.f128.fromAbi(z)));
}
/// Fused multiply-add: Compute x * y + z with a single rounding error.
///
/// We use scaling to avoid overflow/underflow, along with the
/// canonical precision-doubling technique adapted from:
///
///      Dekker, T.  A Floating-Point Technique for Extending the
///      Available Precision.  Numer. Math. 18, 224-242 (1971).
pub fn fma_f128(x: f128, y: f128, z: f128) f128 {
    if (!math.isFinite(x) or !math.isFinite(y)) {
        return x * y + z;
    }
    if (!math.isFinite(z)) {
        return z;
    }
    if (x == 0.0 or y == 0.0) {
        return x * y + z;
    }
    if (z == 0.0) {
        return x * y;
    }

    const x1 = math.frexp(x);
    const ex = x1.exponent;
    const xs = x1.significand;
    const x2 = math.frexp(y);
    const ey = x2.exponent;
    const ys = x2.significand;
    const x3 = math.frexp(z);
    const ez = x3.exponent;
    var zs = x3.significand;

    var spread = ex + ey - ez;
    if (spread < -113) return z;
    if (spread <= 113 * 2) {
        zs = math.scalbn(zs, -spread);
    } else {
        zs = math.copysign(math.floatMin(f128), zs);
    }

    const xy = dd_mul128(xs, ys);
    const r = dd_add128(xy.hi, zs);
    spread = ex + ey;

    if (r.hi == 0.0) {
        return if (xy.lo == 0.0) xy.hi + zs else math.scalbn(xy.lo, spread);
    }

    const adj = add_adjusted128(r.lo, xy.lo);
    if (spread + math.ilogb(r.hi) > -16383) {
        return math.scalbn(r.hi + adj, spread);
    } else {
        return add_and_denorm128(r.hi, adj, spread);
    }
}

pub fn fmal(x: c_longdouble, y: c_longdouble, z: c_longdouble) callconv(.c) c_longdouble {
    switch (@typeInfo(c_longdouble).float.bits) {
        64 => return fma_f64(x, y, z),
        80 => return fma_f80(x, y, z),
        128 => return fma_f128(x, y, z),
        else => comptime unreachable,
    }
}

const dd = struct {
    hi: f64,
    lo: f64,
};

fn dd_add(a: f64, b: f64) dd {
    var ret: dd = undefined;
    ret.hi = a + b;
    const s = ret.hi - a;
    ret.lo = (a - (ret.hi - s)) + (b - s);
    return ret;
}

fn dd_mul(a: f64, b: f64) dd {
    var ret: dd = undefined;
    const split: f64 = 0x1.0p27 + 1.0;

    var p = a * split;
    var ha = a - p;
    ha += p;
    const la = a - ha;

    p = b * split;
    var hb = b - p;
    hb += p;
    const lb = b - hb;

    p = ha * hb;
    const q = ha * lb + la * hb;

    ret.hi = p + q;
    ret.lo = p - ret.hi + q + la * lb;
    return ret;
}

fn add_adjusted(a: f64, b: f64) f64 {
    var sum = dd_add(a, b);
    if (sum.lo != 0) {
        var uhii: u64 = @bitCast(sum.hi);
        if (uhii & 1 == 0) {
            // hibits += copysign(1.0, sum.hi, sum.lo)
            const uloi: u64 = @bitCast(sum.lo);
            uhii = uhii + 1 - ((uhii ^ uloi) >> 62);
            sum.hi = @bitCast(uhii);
        }
    }
    return sum.hi;
}

fn add_and_denorm(a: f64, b: f64, scale: i32) f64 {
    var sum = dd_add(a, b);
    if (sum.lo != 0) {
        var uhii: u64 = @bitCast(sum.hi);
        const bits_lost = -@as(i32, @intCast((uhii >> 52) & 0x7FF)) - scale + 1;
        if ((bits_lost != 1) != (uhii & 1 != 0)) {
            const uloi: u64 = @bitCast(sum.lo);
            uhii = uhii + 1 - (((uhii ^ uloi) >> 62) & 2);
            sum.hi = @bitCast(uhii);
        }
    }
    return math.scalbn(sum.hi, scale);
}

/// A struct that represents a floating-point number with twice the precision
/// of f128.  We maintain the invariant that "hi" stores the high-order
/// bits of the result.
const dd128 = struct {
    hi: f128,
    lo: f128,
};

/// Compute a+b exactly, returning the exact result in a struct dd.  We assume
/// that both a and b are finite, but make no assumptions about their relative
/// magnitudes.
fn dd_add128(a: f128, b: f128) dd128 {
    var ret: dd128 = undefined;
    ret.hi = a + b;
    const s = ret.hi - a;
    ret.lo = (a - (ret.hi - s)) + (b - s);
    return ret;
}

/// Compute a+b, with a small tweak:  The least significant bit of the
/// result is adjusted into a sticky bit summarizing all the bits that
/// were lost to rounding.  This adjustment negates the effects of double
/// rounding when the result is added to another number with a higher
/// exponent.  For an explanation of round and sticky bits, see any reference
/// on FPU design, e.g.,
///
///     J. Coonen.  An Implementation Guide to a Proposed Standard for
///     Floating-Point Arithmetic.  Computer, vol. 13, no. 1, Jan 1980.
fn add_adjusted128(a: f128, b: f128) f128 {
    var sum = dd_add128(a, b);
    if (sum.lo != 0) {
        var uhii: u128 = @bitCast(sum.hi);
        if (uhii & 1 == 0) {
            // hibits += copysign(1.0, sum.hi, sum.lo)
            const uloi: u128 = @bitCast(sum.lo);
            uhii = uhii + 1 - ((uhii ^ uloi) >> 126);
            sum.hi = @bitCast(uhii);
        }
    }
    return sum.hi;
}

/// Compute ldexp(a+b, scale) with a single rounding error. It is assumed
/// that the result will be subnormal, and care is taken to ensure that
/// double rounding does not occur.
fn add_and_denorm128(a: f128, b: f128, scale: i32) f128 {
    var sum = dd_add128(a, b);
    // If we are losing at least two bits of accuracy to denormalization,
    // then the first lost bit becomes a round bit, and we adjust the
    // lowest bit of sum.hi to make it a sticky bit summarizing all the
    // bits in sum.lo. With the sticky bit adjusted, the hardware will
    // break any ties in the correct direction.
    //
    // If we are losing only one bit to denormalization, however, we must
    // break the ties manually.
    if (sum.lo != 0) {
        var uhii: u128 = @bitCast(sum.hi);
        const bits_lost = -@as(i32, @intCast((uhii >> 112) & 0x7FFF)) - scale + 1;
        if ((bits_lost != 1) != (uhii & 1 != 0)) {
            const uloi: u128 = @bitCast(sum.lo);
            uhii = uhii + 1 - (((uhii ^ uloi) >> 126) & 2);
            sum.hi = @bitCast(uhii);
        }
    }
    return math.scalbn(sum.hi, scale);
}

/// Compute a*b exactly, returning the exact result in a struct dd.  We assume
/// that both a and b are normalized, so no underflow or overflow will occur.
/// The current rounding mode must be round-to-nearest.
fn dd_mul128(a: f128, b: f128) dd128 {
    var ret: dd128 = undefined;
    const split: f128 = 0x1.0p57 + 1.0;

    var p = a * split;
    var ha = a - p;
    ha += p;
    const la = a - ha;

    p = b * split;
    var hb = b - p;
    hb += p;
    const lb = b - hb;

    p = ha * hb;
    const q = ha * lb + la * hb;

    ret.hi = p + q;
    ret.lo = p - ret.hi + q + la * lb;
    return ret;
}

test "32" {
    const epsilon = 0.000001;

    try expect(math.approxEqAbs(f32, fma_f32(0.0, 5.0, 9.124), 9.124, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(0.2, 5.0, 9.124), 10.124, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(0.8923, 5.0, 9.124), 13.5855, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(1.5, 5.0, 9.124), 16.624, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(37.45, 5.0, 9.124), 196.374004, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(89.123, 5.0, 9.124), 454.739005, epsilon));
    try expect(math.approxEqAbs(f32, fma_f32(123123.234375, 5.0, 9.124), 615625.295875, epsilon));

    // Avoid double rounding when the f64 sum lands on an f32 midpoint.
    try expectEqual(0x3fc00001, @as(u32, @bitCast(fma_f32(0x1.000002p0, 1.5, -0x1p-60))));
}

test "64" {
    const epsilon = 0.000001;

    try expect(math.approxEqAbs(f64, fma_f64(0.0, 5.0, 9.124), 9.124, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(0.2, 5.0, 9.124), 10.124, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(0.8923, 5.0, 9.124), 13.5855, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(1.5, 5.0, 9.124), 16.624, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(37.45, 5.0, 9.124), 196.374, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(89.123, 5.0, 9.124), 454.739, epsilon));
    try expect(math.approxEqAbs(f64, fma_f64(123123.234375, 5.0, 9.124), 615625.295875, epsilon));

    // Special operands.
    try expect(math.isNan(fma_f64(math.inf(f64), 0.0, 1.0)));
    try expect(math.isNan(fma_f64(math.inf(f64), 1.0, -math.inf(f64))));
    try expectEqual(math.inf(f64), fma_f64(2.0, 3.0, math.inf(f64)));
    try expectEqual(math.inf(f64), fma_f64(math.floatMax(f64), 2.0, 0.0));
    try expect(math.isNan(fma_f64(math.nan(f64), 1.0, 1.0)));

    // Addend dominates product.
    try expectEqual(-1.438e308, fma_f64(-0.6, math.floatTrueMin(f64), -1.438e308));
    try expectEqual(1.0, fma_f64(0x1p-600, 0x1p-600, 1.0));
    try expectEqual(math.floatMax(f64), fma_f64(math.floatTrueMin(f64), math.floatTrueMin(f64), math.floatMax(f64)));

    // Subnormal result is rounded once.
    try expectEqual(0x000d2971831e2f43, @as(u64, @bitCast(fma_f64(
        @bitCast(@as(u64, 0xbbbcae314558d732)),
        @bitCast(@as(u64, 0x843d607d0e518063)),
        @bitCast(@as(u64, 0x800000ba24d8f3ba)),
    ))));
    try expectEqual(0x000516a34ce113eb, @as(u64, @bitCast(fma_f64(
        @bitCast(@as(u64, 0x2af4b8a2ad5294f0)),
        @bitCast(@as(u64, 0x14ef6dd2b62857c2)),
        @bitCast(@as(u64, 0x000000248ff787f4)),
    ))));
    try expectEqual(0x800bccc9d0e68a53, @as(u64, @bitCast(fma_f64(
        @bitCast(@as(u64, 0x3e81368dcd4cb557)),
        @bitCast(@as(u64, 0x817514ce659bdad8)),
        @bitCast(@as(u64, 0x800075cba3b3043c)),
    ))));

    // Sign of zero.
    try expectEqual(0x8000000000000000, @as(u64, @bitCast(fma_f64(
        @bitCast(@as(u64, 0x2001526ce7a829e5)),
        @bitCast(@as(u64, 0xa00c9ac305fd618a)),
        @bitCast(@as(u64, 0x001ef7cb10a75631)),
    ))));
    try expect(!math.signbit(fma_f64(1.0, 1.0, -1.0)));
    try expect(math.signbit(fma_f64(-math.floatTrueMin(f64), 0.5, 0.0)));
    try expect(math.signbit(fma_f64(-0.0, 1.0, -0.0)));
}

test "128" {
    const epsilon = 0.000001;

    try expect(math.approxEqAbs(f128, fma_f128(0.0, 5.0, 9.124), 9.124, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(0.2, 5.0, 9.124), 10.124, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(0.8923, 5.0, 9.124), 13.5855, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(1.5, 5.0, 9.124), 16.624, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(37.45, 5.0, 9.124), 196.374, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(89.123, 5.0, 9.124), 454.739, epsilon));
    try expect(math.approxEqAbs(f128, fma_f128(123123.234375, 5.0, 9.124), 615625.295875, epsilon));

    // Addend dominates product.
    try expectEqual(-1.0e4932, fma_f128(-0.6, math.floatTrueMin(f128), -1.0e4932));
    try expectEqual(0x8000f2eb9b403234570b698042da365d, @as(u128, @bitCast(fma_f128(
        @bitCast(@as(u128, 0xa4d80b69452301dd5a3efab045ca0371)),
        @bitCast(@as(u128, 0x13a5efea97a6ece0f0b24ffab5fcdcb4)),
        @bitCast(@as(u128, 0x8000f2eb9b403234570b698042da365d)),
    ))));

    // Subnormal result is rounded once.
    try expectEqual(0x0000f5ea6135ffda377d6f2322102a7b, @as(u128, @bitCast(fma_f128(
        @bitCast(@as(u128, 0x2d83ef38da3dc9f883f14ecb887541ce)),
        @bitCast(@as(u128, 0x123129a960f91ee507caa6a6702fc33e)),
        @bitCast(@as(u128, 0x0000f5ea6135ffda377d6eff2506556b)),
    ))));

    // Sign of zero.
    try expectEqual(0x80000000000000000000000000000000, @as(u128, @bitCast(fma_f128(
        @bitCast(@as(u128, 0x1fd32f92b54d7cefc06df6f8521f1bc3)),
        @bitCast(@as(u128, 0x202bb49b61ca93fdb382f78b6a2a32e2)),
        @bitCast(@as(u128, 0x8000816f87a4a3a99ed5f1db8e4c0404)),
    ))));
}
