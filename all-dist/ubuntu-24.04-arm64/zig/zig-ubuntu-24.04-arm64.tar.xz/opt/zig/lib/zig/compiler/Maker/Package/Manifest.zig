const Manifest = @This();

const std = @import("std");
const Io = std.Io;
const mem = std.mem;
const Allocator = std.mem.Allocator;
const assert = std.debug.assert;
const Ast = std.zig.Ast;
const testing = std.testing;

const Package = @import("../Package.zig");

pub const max_bytes = 10 * 1024 * 1024;
pub const basename = "build.zig.zon";
pub const max_name_len = 32;
pub const max_version_len = 32;

pub const Dependency = struct {
    location: Location,
    location_tok: Ast.TokenIndex,
    location_node: Ast.Node.Index,
    hash: ?[]const u8,
    hash_tok: Ast.OptionalTokenIndex,
    hash_node: Ast.Node.OptionalIndex,
    node: Ast.Node.Index,
    name_tok: Ast.TokenIndex,
    lazy: bool,
    paths: std.array_hash_map.String(void),
    paths_tok: Ast.OptionalTokenIndex,
    version: std.SemanticVersion,
    version_tok: Ast.OptionalTokenIndex,

    pub const Location = union(enum) {
        url: []const u8,
        path: []const u8,
    };
};

pub const ErrorMessage = struct {
    msg: []const u8,
    tok: Ast.TokenIndex,
    off: u32,
};

name: []const u8,
id: u32,
version: std.SemanticVersion,
version_node: Ast.Node.Index,
dependencies: std.array_hash_map.String(Dependency),
dependencies_node: Ast.Node.OptionalIndex,
paths: std.array_hash_map.String(void),
minimum_zig_version: ?std.SemanticVersion,

errors: []ErrorMessage,
arena_state: std.heap.ArenaAllocator.State,

pub const ParseOptions = struct {
    allow_missing_paths_field: bool = false,
};

pub const Error = Allocator.Error;

pub fn parse(gpa: Allocator, ast: *const Ast, rng: std.Random, options: ParseOptions) Error!Manifest {
    const main_node_index = ast.nodeData(.root).node;

    var arena_instance = std.heap.ArenaAllocator.init(gpa);
    errdefer arena_instance.deinit();

    var p: Parse = .{
        .gpa = gpa,
        .ast = ast.*,
        .arena = arena_instance.allocator(),
        .errors = .empty,

        .name = undefined,
        .id = 0,
        .version = undefined,
        .version_node = undefined,
        .dependencies = .{},
        .dependencies_node = .none,
        .paths = .empty,
        .allow_missing_paths_field = options.allow_missing_paths_field,
        .minimum_zig_version = null,
        .buf = .empty,
    };
    defer p.buf.deinit(gpa);
    defer p.errors.deinit(gpa);
    defer p.dependencies.deinit(gpa);
    defer p.paths.deinit(gpa);

    p.parseRoot(main_node_index, rng) catch |err| switch (err) {
        error.ParseFailure => assert(p.errors.items.len > 0),
        else => |e| return e,
    };

    return .{
        .name = p.name,
        .id = p.id,
        .version = p.version,
        .version_node = p.version_node,
        .dependencies = try p.dependencies.clone(p.arena),
        .dependencies_node = p.dependencies_node,
        .paths = try p.paths.clone(p.arena),
        .minimum_zig_version = p.minimum_zig_version,
        .errors = try p.arena.dupe(ErrorMessage, p.errors.items),
        .arena_state = arena_instance.state,
    };
}

pub fn deinit(man: *Manifest, gpa: Allocator) void {
    man.arena_state.promote(gpa).deinit();
    man.* = undefined;
}

pub fn copyErrorsIntoBundle(
    man: Manifest,
    ast: Ast,
    /// ErrorBundle null-terminated string index
    src_path: u32,
    eb: *std.zig.ErrorBundle.Wip,
) Allocator.Error!void {
    for (man.errors) |msg| {
        const start_loc = ast.tokenLocation(0, msg.tok);

        try eb.addRootErrorMessage(.{
            .msg = try eb.addString(msg.msg),
            .src_loc = try eb.addSourceLocation(.{
                .src_path = src_path,
                .span_start = ast.tokenStart(msg.tok),
                .span_end = @intCast(ast.tokenStart(msg.tok) + ast.tokenSlice(msg.tok).len),
                .span_main = ast.tokenStart(msg.tok) + msg.off,
                .line = @intCast(start_loc.line),
                .column = @intCast(start_loc.column),
                .source_line = try eb.addString(ast.source[start_loc.line_start..start_loc.line_end]),
            }),
        });
    }
}

const Parse = struct {
    gpa: Allocator,
    ast: Ast,
    arena: Allocator,
    buf: std.ArrayList(u8),
    errors: std.ArrayList(ErrorMessage),

    name: []const u8,
    id: u32,
    version: std.SemanticVersion,
    version_node: Ast.Node.Index,
    dependencies: std.array_hash_map.String(Dependency),
    dependencies_node: Ast.Node.OptionalIndex,
    paths: std.array_hash_map.String(void),
    allow_missing_paths_field: bool,
    minimum_zig_version: ?std.SemanticVersion,

    const InnerError = error{ ParseFailure, OutOfMemory };

    fn parseRoot(p: *Parse, node: Ast.Node.Index, rng: std.Random) !void {
        const ast = p.ast;
        const main_token = ast.nodeMainToken(node);

        var buf: [2]Ast.Node.Index = undefined;
        const struct_init = ast.fullStructInit(&buf, node) orelse {
            return fail(p, main_token, "expected top level expression to be a struct", .{});
        };

        var have_name = false;
        var have_version = false;
        var have_included_paths = false;
        var fingerprint: ?Package.Fingerprint = null;

        for (struct_init.ast.fields) |field_init| {
            const name_token = ast.firstToken(field_init) - 2;
            const field_name = try identifierTokenString(p, name_token);
            // We could get fancy with reflection and comptime logic here but doing
            // things manually provides an opportunity to do any additional verification
            // that is desirable on a per-field basis.
            if (mem.eql(u8, field_name, "dependencies")) {
                p.dependencies_node = field_init.toOptional();
                try parseDependencies(p, field_init);
            } else if (mem.eql(u8, field_name, "paths")) {
                have_included_paths = true;
                try parseIncludedPaths(p, &p.paths, field_init);
            } else if (mem.eql(u8, field_name, "name")) {
                p.name = try parseName(p, field_init);
                have_name = true;
            } else if (mem.eql(u8, field_name, "fingerprint")) {
                fingerprint = try parseFingerprint(p, field_init);
            } else if (mem.eql(u8, field_name, "version")) {
                p.version_node = field_init;
                have_version = true;
                if (parseVersion(p, field_init)) |v| {
                    p.version = v;
                } else |err| switch (err) {
                    else => |e| return e,
                    error.ParseFailure => {},
                }
            } else if (mem.eql(u8, field_name, "minimum_zig_version")) {
                const version_text = try parseString(p, field_init);
                p.minimum_zig_version = std.SemanticVersion.parse(version_text) catch |err| v: {
                    try appendError(p, ast.nodeMainToken(field_init), "unable to parse semantic version: {s}", .{@errorName(err)});
                    break :v null;
                };
            } else {
                // Ignore unknown fields so that we can add fields in future zig
                // versions without breaking older zig versions.
            }
        }

        if (!have_name) {
            try appendError(p, main_token, "missing top-level 'name' field", .{});
        } else {
            if (fingerprint) |n| {
                if (!n.validate(p.name)) {
                    return fail(p, main_token, "invalid fingerprint: 0x{x}; if this is a new or forked package, use this value: 0x{x}", .{
                        n.int(), Package.Fingerprint.generate(rng, p.name).int(),
                    });
                }
                p.id = n.id;
            } else {
                try appendError(p, main_token, "missing top-level 'fingerprint' field; suggested value: 0x{x}", .{
                    Package.Fingerprint.generate(rng, p.name).int(),
                });
            }
        }

        if (!have_version) {
            try appendError(p, main_token, "missing top-level 'version' field", .{});
        }

        if (!have_included_paths) {
            if (p.allow_missing_paths_field) {
                try p.paths.put(p.gpa, "", {});
            } else {
                try appendError(p, main_token, "missing top-level 'paths' field", .{});
            }
        }
    }

    fn parseVersion(p: *Parse, node: Ast.Node.Index) InnerError!std.SemanticVersion {
        const ast = p.ast;
        const version_text = try parseString(p, node);
        if (version_text.len > max_version_len) {
            try appendError(p, ast.nodeMainToken(node), "version string length {d} exceeds maximum of {d}", .{
                version_text.len, max_version_len,
            });
        }
        return std.SemanticVersion.parse(version_text) catch |err| {
            return fail(p, ast.nodeMainToken(node), "parsing semantic version {q} failed: {t}", .{
                version_text, err,
            });
        };
    }

    fn parseDependencies(p: *Parse, node: Ast.Node.Index) !void {
        const ast = p.ast;

        var buf: [2]Ast.Node.Index = undefined;
        const struct_init = ast.fullStructInit(&buf, node) orelse {
            const tok = ast.nodeMainToken(node);
            return fail(p, tok, "expected dependencies expression to be a struct", .{});
        };

        for (struct_init.ast.fields) |field_init| {
            const name_token = ast.firstToken(field_init) - 2;
            const dep_name = try identifierTokenString(p, name_token);
            const dep = try parseDependency(p, field_init);
            try p.dependencies.put(p.gpa, dep_name, dep);
        }
    }

    fn parseDependency(p: *Parse, node: Ast.Node.Index) !Dependency {
        const ast = p.ast;

        var buf: [2]Ast.Node.Index = undefined;
        const struct_init = ast.fullStructInit(&buf, node) orelse {
            const tok = ast.nodeMainToken(node);
            return fail(p, tok, "expected dependency expression to be a struct", .{});
        };

        var dep: Dependency = .{
            .location = undefined,
            .location_tok = undefined,
            .location_node = undefined,
            .hash = null,
            .hash_tok = .none,
            .hash_node = .none,
            .node = node,
            .name_tok = undefined,
            .lazy = false,
            .paths = .empty,
            .paths_tok = .none,
            .version = undefined,
            .version_tok = .none,
        };
        var has_location = false;

        for (struct_init.ast.fields) |field_init| {
            const name_token = ast.firstToken(field_init) - 2;
            dep.name_tok = name_token;
            const field_name = try identifierTokenString(p, name_token);
            // We could get fancy with reflection and comptime logic here but doing
            // things manually provides an opportunity to do any additional verification
            // that is desirable on a per-field basis.
            if (mem.eql(u8, field_name, "url")) {
                if (has_location) {
                    return fail(p, ast.nodeMainToken(field_init), "dependency should specify only one of 'url' and 'path' fields.", .{});
                }
                dep.location = .{
                    .url = parseString(p, field_init) catch |err| switch (err) {
                        error.ParseFailure => continue,
                        else => |e| return e,
                    },
                };
                has_location = true;
                dep.location_tok = ast.nodeMainToken(field_init);
                dep.location_node = field_init;
            } else if (mem.eql(u8, field_name, "path")) {
                if (has_location) {
                    return fail(p, ast.nodeMainToken(field_init), "dependency should specify only one of 'url' and 'path' fields.", .{});
                }
                dep.location = .{
                    .path = parseString(p, field_init) catch |err| switch (err) {
                        error.ParseFailure => continue,
                        else => |e| return e,
                    },
                };
                has_location = true;
                dep.location_tok = ast.nodeMainToken(field_init);
                dep.location_node = field_init;
            } else if (mem.eql(u8, field_name, "hash")) {
                dep.hash = parseHash(p, field_init) catch |err| switch (err) {
                    error.ParseFailure => continue,
                    else => |e| return e,
                };
                dep.hash_tok = .fromToken(ast.nodeMainToken(field_init));
                dep.hash_node = field_init.toOptional();
            } else if (mem.eql(u8, field_name, "lazy")) {
                dep.lazy = parseBool(p, field_init) catch |err| switch (err) {
                    error.ParseFailure => continue,
                    else => |e| return e,
                };
            } else if (mem.eql(u8, field_name, "paths")) {
                dep.paths_tok = .fromToken(name_token);
                try parseIncludedPaths(p, &dep.paths, field_init);
            } else if (mem.eql(u8, field_name, "version")) {
                if (parseVersion(p, field_init)) |v| {
                    dep.version = v;
                    dep.version_tok = .fromToken(name_token);
                } else |err| switch (err) {
                    else => |e| return e,
                    error.ParseFailure => {},
                }
            } else {
                // Ignore unknown fields so that we can add fields in future zig
                // versions without breaking older zig versions.
            }
        }

        if (!has_location) {
            try appendError(p, ast.nodeMainToken(node), "dependency requires location field, one of 'url' or 'path'.", .{});
        }

        return dep;
    }

    fn parseIncludedPaths(p: *Parse, paths: *std.array_hash_map.String(void), node: Ast.Node.Index) !void {
        const ast = p.ast;

        var buf: [2]Ast.Node.Index = undefined;
        const array_init = ast.fullArrayInit(&buf, node) orelse {
            const tok = ast.nodeMainToken(node);
            return fail(p, tok, "expected paths expression to be a list of strings", .{});
        };

        for (array_init.ast.elements) |elem_node| {
            const path_string = try parseString(p, elem_node);
            // This is normalized so that it can be used in string comparisons
            // against file system paths.
            const normalized = try std.fs.path.resolve(p.arena, &.{path_string});
            if (try paths.fetchPut(p.gpa, normalized, {})) |kv| {
                return fail(p, ast.nodeMainToken(elem_node), "path {q} already included as {q}", .{
                    normalized, kv.key,
                });
            }
        }
    }

    fn parseBool(p: *Parse, node: Ast.Node.Index) !bool {
        const ast = p.ast;
        if (ast.nodeTag(node) != .identifier) {
            return fail(p, ast.nodeMainToken(node), "expected identifier", .{});
        }
        const ident_token = ast.nodeMainToken(node);
        const token_bytes = ast.tokenSlice(ident_token);
        if (mem.eql(u8, token_bytes, "true")) {
            return true;
        } else if (mem.eql(u8, token_bytes, "false")) {
            return false;
        } else {
            return fail(p, ident_token, "expected boolean", .{});
        }
    }

    fn parseFingerprint(p: *Parse, node: Ast.Node.Index) !Package.Fingerprint {
        const ast = p.ast;
        const main_token = ast.nodeMainToken(node);
        if (ast.nodeTag(node) != .number_literal) {
            return fail(p, main_token, "expected integer literal", .{});
        }
        const token_bytes = ast.tokenSlice(main_token);
        const parsed = std.zig.parseNumberLiteral(token_bytes);
        switch (parsed) {
            .int => |n| return @bitCast(n),
            .big_int, .float => return fail(p, main_token, "expected u64 integer literal, found {s}", .{
                @tagName(parsed),
            }),
            .failure => |err| return fail(p, main_token, "bad integer literal: {s}", .{@tagName(err)}),
        }
    }

    fn parseName(p: *Parse, node: Ast.Node.Index) ![]const u8 {
        const ast = p.ast;
        const main_token = ast.nodeMainToken(node);

        if (ast.nodeTag(node) != .enum_literal)
            return fail(p, main_token, "expected enum literal", .{});

        const ident_name = ast.tokenSlice(main_token);
        if (mem.startsWith(u8, ident_name, "@"))
            return fail(p, main_token, "name must be a valid bare zig identifier", .{});

        if (ident_name.len > max_name_len)
            return fail(p, main_token, "name '{f}' exceeds max length of {d}", .{
                std.zig.fmtId(ident_name), max_name_len,
            });

        return ident_name;
    }

    fn parseString(p: *Parse, node: Ast.Node.Index) ![]const u8 {
        const ast = p.ast;
        if (ast.nodeTag(node) != .string_literal) {
            return fail(p, ast.nodeMainToken(node), "expected string literal", .{});
        }
        const str_lit_token = ast.nodeMainToken(node);
        const token_bytes = ast.tokenSlice(str_lit_token);
        p.buf.clearRetainingCapacity();
        try parseStrLit(p, str_lit_token, &p.buf, token_bytes, 0);
        const duped = try p.arena.dupe(u8, p.buf.items);
        return duped;
    }

    fn parseHash(p: *Parse, node: Ast.Node.Index) ![]const u8 {
        const ast = p.ast;
        const tok = ast.nodeMainToken(node);
        const h = try parseString(p, node);
        switch (Package.Hash.validate(h)) {
            .ok => return h,
            else => |t| return fail(p, tok, "invalid hash: {t}", .{t}),
        }
    }

    /// TODO: try to DRY this with AstGen.identifierTokenString
    fn identifierTokenString(p: *Parse, token: Ast.TokenIndex) InnerError![]const u8 {
        const ast = p.ast;
        assert(ast.tokenTag(token) == .identifier);
        const ident_name = ast.tokenSlice(token);
        if (!mem.startsWith(u8, ident_name, "@")) {
            return ident_name;
        }
        p.buf.clearRetainingCapacity();
        try parseStrLit(p, token, &p.buf, ident_name, 1);
        const duped = try p.arena.dupe(u8, p.buf.items);
        return duped;
    }

    /// TODO: try to DRY this with AstGen.parseStrLit
    fn parseStrLit(
        p: *Parse,
        token: Ast.TokenIndex,
        buf: *std.ArrayList(u8),
        bytes: []const u8,
        offset: u32,
    ) InnerError!void {
        const raw_string = bytes[offset..];
        const result = r: {
            var aw: std.Io.Writer.Allocating = .fromArrayList(p.gpa, buf);
            defer buf.* = aw.toArrayList();
            break :r std.zig.string_literal.parseWrite(&aw.writer, raw_string) catch |err| switch (err) {
                error.WriteFailed => return error.OutOfMemory,
            };
        };
        switch (result) {
            .success => {},
            .failure => |err| try p.appendErrorOff(token, @intCast(offset + err.offset()), "{f}", .{
                err.fmt(bytes[offset..]),
            }),
        }
    }

    fn fail(
        p: *Parse,
        tok: Ast.TokenIndex,
        comptime fmt: []const u8,
        args: anytype,
    ) InnerError {
        try appendError(p, tok, fmt, args);
        return error.ParseFailure;
    }

    fn appendError(p: *Parse, tok: Ast.TokenIndex, comptime fmt: []const u8, args: anytype) !void {
        return appendErrorOff(p, tok, 0, fmt, args);
    }

    fn appendErrorOff(
        p: *Parse,
        tok: Ast.TokenIndex,
        byte_offset: u32,
        comptime fmt: []const u8,
        args: anytype,
    ) Allocator.Error!void {
        try p.errors.append(p.gpa, .{
            .msg = try p.arena.print(fmt, args),
            .tok = tok,
            .off = byte_offset,
        });
    }
};

pub fn load(
    io: Io,
    arena: Allocator,
    manifest_path: std.Build.Cache.Path,
    ast: *std.zig.Ast,
    error_bundle: *std.zig.ErrorBundle.Wip,
    manifest: *Manifest,
    allow_missing_paths_field: bool,
) !void {
    const manifest_bytes = try manifest_path.root_dir.handle.readFileAllocOptions(
        io,
        manifest_path.sub_path,
        arena,
        .limited(max_bytes),
        .@"1",
        0,
    );

    ast.* = try std.zig.Ast.parse(arena, manifest_bytes, .{ .mode = .zon });

    if (ast.errors.len > 0) {
        const file_path = try manifest_path.joinString(arena, "");
        try std.zig.putAstErrorsIntoBundle(arena, ast.*, file_path, error_bundle);
        return error.ErrorsBundled;
    }

    const rng: std.Random.IoSource = .{ .io = io };

    manifest.* = try parse(arena, ast, rng.interface(), .{
        .allow_missing_paths_field = allow_missing_paths_field,
    });

    if (manifest.errors.len > 0) {
        const src_path = try error_bundle.printString("{f}", .{manifest_path});
        try manifest.copyErrorsIntoBundle(ast.*, src_path, error_bundle);
        return error.ErrorsBundled;
    }
}

test "basic" {
    const gpa = testing.allocator;

    const example =
        \\.{
        \\    .name = .foo,
        \\    .fingerprint = 0x8c736521490b23df,
        \\    .version = "3.2.1",
        \\    .paths = .{""},
        \\    .dependencies = .{
        \\        .bar = .{
        \\            .url = "https://example.com/baz.tar.gz",
        \\            .hash = "libmp3lame-3.100.1-6-67wlF_KvEwDRCT3pTpcDzi5KGntWCEoM-WtvVPEWdlk5",
        \\        },
        \\    },
        \\}
    ;

    var ast = try Ast.parse(gpa, example, .{ .mode = .zon });
    defer ast.deinit(gpa);

    try testing.expect(ast.errors.len == 0);

    var rng = std.Random.DefaultPrng.init(0);

    var manifest = try Manifest.parse(gpa, &ast, rng.random(), .{});
    defer manifest.deinit(gpa);

    try testing.expect(manifest.errors.len == 0);
    try testing.expectEqualStrings("foo", manifest.name);

    try testing.expectEqual(@as(std.SemanticVersion, .{
        .major = 3,
        .minor = 2,
        .patch = 1,
    }), manifest.version);

    try testing.expect(manifest.dependencies.count() == 1);
    try testing.expectEqualStrings("bar", manifest.dependencies.keys()[0]);
    try testing.expectEqualStrings(
        "https://example.com/baz.tar.gz",
        manifest.dependencies.values()[0].location.url,
    );
    try testing.expectEqualStrings(
        "libmp3lame-3.100.1-6-67wlF_KvEwDRCT3pTpcDzi5KGntWCEoM-WtvVPEWdlk5",
        manifest.dependencies.values()[0].hash orelse return error.TestFailed,
    );

    try testing.expect(manifest.minimum_zig_version == null);
}

test "minimum_zig_version" {
    const gpa = testing.allocator;

    const example =
        \\.{
        \\    .name = .foo,
        \\    .fingerprint = 0x8c736521490b23df,
        \\    .version = "3.2.1",
        \\    .paths = .{""},
        \\    .minimum_zig_version = "0.11.1",
        \\}
    ;

    var ast = try Ast.parse(gpa, example, .{ .mode = .zon });
    defer ast.deinit(gpa);

    try testing.expect(ast.errors.len == 0);

    var rng = std.Random.DefaultPrng.init(0);

    var manifest = try Manifest.parse(gpa, &ast, rng.random(), .{});
    defer manifest.deinit(gpa);

    try testing.expect(manifest.errors.len == 0);
    try testing.expect(manifest.dependencies.count() == 0);

    try testing.expect(manifest.minimum_zig_version != null);

    try testing.expectEqual(@as(std.SemanticVersion, .{
        .major = 0,
        .minor = 11,
        .patch = 1,
    }), manifest.minimum_zig_version.?);
}

test "minimum_zig_version - invalid version" {
    const gpa = testing.allocator;

    const example =
        \\.{
        \\    .name = .foo,
        \\    .fingerprint = 0x8c736521490b23df,
        \\    .version = "3.2.1",
        \\    .minimum_zig_version = "X.11.1",
        \\    .paths = .{""},
        \\}
    ;

    var ast = try Ast.parse(gpa, example, .{ .mode = .zon });
    defer ast.deinit(gpa);

    try testing.expect(ast.errors.len == 0);

    var rng = std.Random.DefaultPrng.init(0);

    var manifest = try Manifest.parse(gpa, &ast, rng.random(), .{});
    defer manifest.deinit(gpa);

    try testing.expect(manifest.errors.len == 1);
    try testing.expect(manifest.dependencies.count() == 0);

    try testing.expect(manifest.minimum_zig_version == null);
}
